/**
 * @param {String} tweet
 * @returns {String[]}
 */
module.exports = function (tweet) {

};
