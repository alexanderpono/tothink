/**
 * @param {String[]} hashtags
 * @returns {String}
 */
module.exports = function (hashtags) {

};
