/**
 * @param {String} date
 * @returns {Object}
 */
module.exports = function (date) {

};
